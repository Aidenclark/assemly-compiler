#ifndef BUILD_TREE_H
#define BUILD_TREE_H
#include "node.h"

//node_t *insert (node_t *trees, int value, int level);
node_t *insert (node_t *trees, int val, int lv);

#endif